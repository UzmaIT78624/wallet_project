from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from.serializers import UserSerializer,TransactionSerializer
from rest_framework import generics
from .models import User
from .models import Transaction
#List Users API
class ListUsersView(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

#list Update Wallet API
@api_view(["POST"])
def update_wallet(request,user_id):
    try:
        user = User.objects.get(id=user_id) 
    except User.DoesNotExist:
        return Response({"error":"user not found"},status=404)

    amount = request.data.get("amount")   
    if amount is None:
        return Response({"error":"Amount is required"},status=400)
    
    user.wallet_balance+=float(amount)
    user.save()

    #create transaction record
    Transaction.objects.create(user=user ,amount=amount)

    return Response({"message":"wallet updated","wallet_balance":"user.wallet_balance"}),

#3)Fetch Transactions API
class UserTransactionsView(generics.ListAPIView):
    serializer_class= TransactionSerializer

    def get_queryset(self):
        user_id=self.kwargs['user_id']
        return Transaction.objects.filter(user_id=user_id)
 
