from django.urls import path
from .views import ListUsersView,update_wallet,UserTransactionsView

urlpatterns=[
    path("user/",ListUsersView.as_view(),name="list-users"),
    path("wallet/<int:user_id>/update/",update_wallet,name="update-wallet"),
    path("transaction/<int:user_id>/",UserTransactionsView.as_view(),name="user-transactions"),
]